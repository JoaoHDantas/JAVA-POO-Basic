import java.util.ArrayList;
import java.util.Scanner;

public class ServicoPet implements ServicoVeterinario {
    
    ArrayList<Pet> animais = new ArrayList<>(); 
    Scanner input = new Scanner(System.in);

  //Adicionar o Animal a array list, cadastrando ele
  public void cadastrarAnimal(Pet animal){    
    animais.add(animal);
    
  }

  public void menu(Pet pet){
    int aux = 123;
    System.out.println("Bem Vindo ao menu do "+ pet.getNome());
    while (true) {
      System.out.println("Digite o número que você deseja realizar o serviço:"+
      "\n1- Vacinar\n2- Banho\n3- Tosar\n4- Verificar se o animal foi vacinado\n5- Informações do pet\n0- Finalizar");
      aux = input.nextInt();
      if(aux == 1){
        realizarServico(pet);
      }else if(aux == 2){
        darBanho(pet);
      }else if(aux == 3){
        tosar(pet);
      }else if(aux == 4){
        validarVacina(pet);
      }else if(aux == 5){
        infoPet(pet);
      }else if(aux == 0){
        break;
      }else{
        System.out.println("Número Invalido");
      }
    }
  }




  public void infoPet(Pet animal){
    System.out.println("-----------------------\n Informações do seu pet \n-----------------------");
    System.out.println("Nome: "+animal.getNome());
    System.out.println("Peso: "+animal.getPeso());
    System.out.println("Idade: "+animal.getIdade());
    System.out.println("Raca: "+animal.getRaca());
    System.out.println("Sexo: "+animal.getSexo());
  }



  //verificar se o animal está dentro da array list, retornando true or false
 public boolean buscarAnimal(String nome){
    for(Pet pets : animais){
      if (nome.equals(pets.getNome())){
        return true;
      }
    }
    System.out.println(nome+" não cadastrado:");
    return false;
 }



 public boolean verificarSeEstaCadastrado(String nome){
    for(Pet pets : animais){
      if (nome.equals(pets.getNome())){
        System.out.println("Seu animal está cadastrado, aproveite os nossos servicos");
        return true;
    }
  }
    System.out.println(nome+" não cadastrado:");
    return false;
  }




  //metodo de dar vacina
  public void realizarServico(Pet animal) {
    if(buscarAnimal(animal.getNome())){
      System.out.println("-----------------------\nVacina aplicada em " + animal.getNome()+"\n-----------------------"); 
      animal.setVacina(true);
      }
    }



  //metodo de dar banho  
  public void darBanho(Pet animal) {
    if(buscarAnimal(animal.getNome())){
      System.out.println("-----------------------\nO " + animal.getNome() +" tomou banho\n----------------------- ");
    }
  }




  //metodo de tosar
  public void tosar(Pet animal) {
    if(buscarAnimal(animal.getNome())){
    System.out.println("-----------------------\nO " + animal.getNome() + " foi tosado\n-----------------------");
    }
  }



  //metodo de verificar se o animal tomou a vacina ou não
  public void validarVacina(Pet animal) {
    if(buscarAnimal(animal.getNome())){
      if(animal.isVacina()){
        System.out.println("-----------------------\nO " + animal.getNome() + " está vacinado\n-----------------------");
      }else{
        System.out.println("-----------------------\nO " + animal.getNome() + " não está vacinado:\n-----------------------");
      }

    } 

  }

}
