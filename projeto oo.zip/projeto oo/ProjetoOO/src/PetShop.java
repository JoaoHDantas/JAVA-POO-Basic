import java.util.Scanner;
/* Criação de um aplicativo em java de gestão de um petshop, controle de vacinas, 
 * 
 * Interface;
 * Possui entrada e saida;
 * Composição Animal/Pet;
 * Classe abstrata;
 * Teste de unidade;
 * Funções:
 * Cadastra os animais no Array list de Petshop;
 * Verifica se o animal está cadastrado na lista do petshop buscando pelo nome - entrada
 * Realiza servico para vacinar seu pet, uma vez vacinado pode checar se ele já está vacinado ou não
 * Dá Banho no animal
 * Tosar o animal
 * Verificar informações do seu pet
 * 
 * OBS:Todos os métodos verificam antes se o animal está cadastrado antes de prosseguir; 
 */
public class PetShop {

  public static void main(String[] args) {
    System.out.println("-Bem vindo ao PetShop limpinho e bonitinho-");
    ServicoPet servico = new ServicoPet();
    Scanner input = new Scanner(System.in);

    Pet pet1 = new Pet("toto","Pinsher","Macho",2.00,1);
    Pet pet2 = new Pet("pepe","Buffus regularis","Macho",6.00,2);
    Pet pet3 = new Pet("jorge","Macaco","Macho",3.00,2);
    
    
    servico.cadastrarAnimal(pet1);
    servico.cadastrarAnimal(pet2);
    servico.cadastrarAnimal(pet3);
  
    //Digite o nome do Animal
    System.out.println("Verifique se seu animal está cadastrado. Digite o nome dele:");
    servico.verificarSeEstaCadastrado(input.nextLine());

    //Menu do pet1 'toto'
    servico.menu(pet1);
    //Menu do pet2 'pepe'
    servico.menu(pet2);
    //Menu do pet3 'jorge'
    servico.menu(pet3);
    


    System.out.println("Obrigada por utilizar nossos serviços, volte sempre :)");    


    input.close();
  }
  

}