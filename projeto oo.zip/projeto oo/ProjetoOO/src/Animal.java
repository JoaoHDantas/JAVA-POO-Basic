public abstract class Animal {
  //criando a classe abstrata e os objetos 
  private String nome;
  private String raca;
  private String sexo;
  private double peso;
  private int idade;
  private boolean vacina = false;

  //metodo construtor da classe Animal
  public Animal(String nome, String raca, String sexo, double peso, int idade) {
    this.nome = nome;
    this.raca = raca;
    this.sexo = sexo;
    this.peso = peso;
    this.idade = idade;
  }

//get e set dos objetos 
public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public String getRaca() {
	return raca;
}
public void setRaca(String raca) {
	this.raca = raca;
}
public String getSexo() {
	return sexo;
}
public void setSexo(String sexo) {
	this.sexo = sexo;
}
public double getPeso() {
	return peso;
}
public void setPeso(double peso) {
	this.peso = peso;
}
public int getIdade() {
	return idade;
}
public void setIdade(int idade) {
	this.idade = idade;
}


public boolean isVacina() {
  return vacina;
}


public void setVacina(boolean vacina) {
  this.vacina = vacina;
}

}
