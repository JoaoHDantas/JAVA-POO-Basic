import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PetShopTest {
    
    @Test
    void verificarSeEstaCadastrado(){
        ServicoPet servico = new ServicoPet();
        Pet pet1 = new Pet("toto","Pinsher","Macho",2.00,1);
        servico.cadastrarAnimal(pet1);

        assertEquals(true, servico.verificarSeEstaCadastrado("toto"));
    }
    
    }