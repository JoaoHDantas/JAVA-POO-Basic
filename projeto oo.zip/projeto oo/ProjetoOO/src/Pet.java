public class Pet extends Animal{


  public Pet(String nome, String raca, String sexo, double peso, int idade) {
    super(nome, raca, sexo, peso, idade);
    
  }

  @Override
  public void setIdade(int idade) {
    super.setIdade(idade);
  }

  @Override
  public void setNome(String nome) {
    super.setNome(nome);
  }

  @Override
  public void setPeso(double peso) {
    super.setPeso(peso);
  }

  @Override
  public void setRaca(String raca) {
    super.setRaca(raca);
  }

  @Override
  public void setSexo(String sexo) {
    super.setSexo(sexo);
  }

  @Override
  public void setVacina(boolean vacina) {
    super.setVacina(vacina);
  }
  

}
  