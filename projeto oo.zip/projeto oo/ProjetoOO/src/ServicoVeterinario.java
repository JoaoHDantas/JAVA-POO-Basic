public interface ServicoVeterinario {
   //criando os metodos 
   public void cadastrarAnimal(Pet animal);
   public boolean buscarAnimal(String nome);
   public void realizarServico(Pet animal);
   public void darBanho(Pet animal);
   public void tosar(Pet animal);
   public void validarVacina(Pet animal);
   public void menu(Pet animal);
   
}
